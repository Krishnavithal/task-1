function validate(){
    var a = /^[0-9]+$/;
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var email=document.getElementById("email");
    var fname=document.getElementById("first");
    var role=document.getElementById("role");
    var gender=document.getElementById("gender");
    var contact=document.getElementById("contact");
    if(fname.value=="")
    {
        alert("First Name can't be empty.");
        return;
    }
    if(role.value=="")
    {
        alert("Please select a roleId.");
        return;
    }
    if(gender.value=="")
    {
        alert("Please select gender.");
        return;
    }
    if(!(contact.value.match(a))||contact.value.length!=10)
    {
        alert("Empty or Invalid contact number.");
        return;
    }
    if(!(email.value.match(mailformat)))
    {
        alert("Invalid Email address.");
        return;
    }
}